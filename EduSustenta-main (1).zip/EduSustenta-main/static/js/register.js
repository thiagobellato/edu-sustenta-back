// static/js/register.js

document.addEventListener('DOMContentLoaded', function() {
    
    // --- 1. Elementos da UI de Escolha ---
    const roleChooser = document.getElementById('role-chooser');
    const formAlunoWrapper = document.getElementById('form-aluno-wrapper');
    const formProfessorWrapper = document.getElementById('form-professor-wrapper');
    const btnEscolhaAluno = document.getElementById('btn-escolha-aluno');
    const btnEscolhaProfessor = document.getElementById('btn-escolha-professor');
    const btnsBack = document.querySelectorAll('.btn-back');

    // --- 2. Elementos do Form Aluno (COM IDs CORRIGIDOS) ---
    const formAluno = {
        btnConsultar: document.getElementById('id_consultar_cpf_aluno_btn'),
        cpfInput: document.getElementById('id_aluno-cpf'), // MUDADO
        nameInput: document.getElementById('id_aluno-name'), // MUDADO
        birthDateInput: document.getElementById('id_aluno-birth_date'), // MUDADO
        statusSpan: document.getElementById('cpf-status-aluno')
    };

    // --- 3. Elementos do Form Professor (COM IDs CORRIGIDOS) ---
    const formProfessor = {
        btnConsultar: document.getElementById('id_consultar_cpf_professor_btn'),
        cpfInput: document.getElementById('id_prof-cpf'), // MUDADO
        nameInput: document.getElementById('id_prof-name'), // MUDADO
        birthDateInput: document.getElementById('id_prof-birth_date'), // MUDADO
        statusSpan: document.getElementById('cpf-status-professor'),
        
        // Campos condicionais
        chkNaoTenhoMatricula: document.getElementById('id_prof-nao_tenho_matricula'), // MUDADO
        matriculaWrapper: document.getElementById('field-wrapper-matricula'),
        comprovanteWrapper: document.getElementById('field-wrapper-comprovante')
    };

    // --- 4. Função Genérica de Consulta CPF (Sem mudanças na lógica) ---
    function consultarCPF(formElements, ageCheck = false) {
        // Verifica se os elementos foram encontrados (importante para depurar)
        if (!formElements.cpfInput || !formElements.nameInput || !formElements.birthDateInput) {
            console.error('JS Error: Um ou mais IDs de formulário não foram encontrados. Verifique os prefixos "aluno-" e "prof-".');
            return;
        }

        const cpf = formElements.cpfInput.value.replace(/\D/g, '');
        const statusSpan = formElements.statusSpan;

        if (cpf.length !== 11) {
            statusSpan.style.color = 'red';
            statusSpan.textContent = 'CPF inválido. Deve ter 11 números.';
            return;
        }
        
        statusSpan.style.color = 'blue';
        statusSpan.textContent = 'Consultando...';
        
        const url = `/api/consult-cpf/${cpf}/`;

        fetch(url)
            .then(response => {
                if (!response.ok) throw new Error(`Erro ${response.status}. CPF não encontrado.`);
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    if (ageCheck && data.age < 18) {
                        statusSpan.style.color = 'red';
                        statusSpan.textContent = 'ERRO: Cadastro de professor é permitido apenas para maiores de 18 anos.';
                        formElements.nameInput.value = '';
                        formElements.birthDateInput.value = '';
                        return;
                    }
                    statusSpan.style.color = 'green';
                    statusSpan.textContent = 'CPF validado!';
                    formElements.nameInput.value = data.name;
                    formElements.birthDateInput.value = data.birth_date;
                } else {
                    throw new Error(data.error || 'Erro ao consultar CPF.');
                }
            })
            .catch(error => {
                statusSpan.style.color = 'red';
                statusSpan.textContent = error.message;
                formElements.nameInput.value = '';
                formElements.birthDateInput.value = '';
            });
    }

    // --- 5. Lógica de Eventos (Listeners) ---
    if (btnEscolhaAluno) {
        btnEscolhaAluno.addEventListener('click', () => {
            roleChooser.style.display = 'none';
            formAlunoWrapper.style.display = 'block';
            formProfessorWrapper.style.display = 'none';
        });
    }

    if (btnEscolhaProfessor) {
        btnEscolhaProfessor.addEventListener('click', () => {
            roleChooser.style.display = 'none';
            formAlunoWrapper.style.display = 'none';
            formProfessorWrapper.style.display = 'block';
            
            // Lógica inicial de exibição (TEM matrícula)
            if (formProfessor.matriculaWrapper) {
                 formProfessor.matriculaWrapper.style.display = 'block';
                 formProfessor.comprovanteWrapper.style.display = 'none';
            }
        });
    }

    btnsBack.forEach(btn => {
        btn.addEventListener('click', () => {
            roleChooser.style.display = 'block';
            formAlunoWrapper.style.display = 'none';
            formProfessorWrapper.style.display = 'none';
        });
    });

    if (formAluno.btnConsultar) {
        formAluno.btnConsultar.addEventListener('click', () => {
            consultarCPF(formAluno, false);
        });
    }
    
    if (formProfessor.btnConsultar) {
        formProfessor.btnConsultar.addEventListener('click', () => {
            consultarCPF(formProfessor, true);
        });
    }

    if (formProfessor.chkNaoTenhoMatricula) {
        formProfessor.chkNaoTenhoMatricula.addEventListener('change', (e) => {
            if (e.target.checked) {
                // NÃO tem matrícula
                formProfessor.matriculaWrapper.style.display = 'none';
                formProfessor.comprovanteWrapper.style.display = 'block';
            } else {
                // TEM matrícula
                formProfessor.matriculaWrapper.style.display = 'block';
                formProfessor.comprovanteWrapper.style.display = 'none';
            }
        });
    }
});