// Animação suave ao rolar os cards das features
document.addEventListener("scroll", () => {
  const cards = document.querySelectorAll(".feature-card");
  const trigger = window.innerHeight * 0.85;

  cards.forEach(card => {
    const top = card.getBoundingClientRect().top;
    if (top < trigger) {
      card.style.opacity = "1";
      card.style.transform = "translateY(0)";
    } else {
      card.style.opacity = "0";
      card.style.transform = "translateY(40px)";
    }
  });
});

// Efeito de clique nos botões
document.querySelectorAll(".btn").forEach(btn => {
  btn.addEventListener("mousedown", () => (btn.style.transform = "scale(0.95)"));
  btn.addEventListener("mouseup", () => (btn.style.transform = "scale(1)"));
});
