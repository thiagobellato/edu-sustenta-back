# api/views.py

from django.http import JsonResponse
from django.conf import settings
from django.views.decorators.http import require_GET
import requests
import re
from datetime import datetime

@require_GET
def consult_cpf(request, cpf):
    # Limpa o CPF para conter apenas números
    cpf_cleaned = re.sub(r'\D', '', cpf)

    if not cpf_cleaned.isdigit() or len(cpf_cleaned) != 11:
        return JsonResponse({'success': False, 'error': 'Formato de CPF inválido.'}, status=400)

    headers = {
        'x-api-key': settings.CPF_HUB_API_KEY,
        'Accept': 'application/json'
    }
    url = f"https://api.cpfhub.io/cpf/{cpf_cleaned}"

    try:
        response = requests.get(url, headers=headers, timeout=5) # Timeout de 5s
        response.raise_for_status() # Lança erro para status 4xx/5xx
        
        data = response.json()

        if data.get('success'):
            api_data = data.get('data', {})
            
            # Formato da API: "15/06/1990"
            # Formato do HTML <input type="date">: "1990-06-15"
            # Precisamos converter
            birth_date_str = api_data.get('birthDate')
            birth_date_formatted = ''
            if birth_date_str:
                try:
                    # Converte de DD/MM/AAAA para AAAA-MM-DD
                    date_obj = datetime.strptime(birth_date_str, '%d/%m/%Y')
                    birth_date_formatted = date_obj.strftime('%Y-%m-%d')
                except ValueError:
                    pass # Deixa em branco se o formato for inesperado

            return JsonResponse({
                'success': True,
                'name': api_data.get('name'),
                'birth_date': birth_date_formatted # Envia no formato AAAA-MM-DD
            })
        else:
            return JsonResponse({'success': False, 'error': 'CPF não encontrado ou API recusou.'}, status=404)

    except requests.exceptions.HTTPError as e:
        return JsonResponse({'success': False, 'error': f'Erro da API: {e.response.status_code}'}, status=e.response.status_code)
    except requests.exceptions.RequestException as e:
        return JsonResponse({'success': False, 'error': f'Erro de conexão: {e}'}, status=500)