from django.urls import path
from . import views

urlpatterns = [
    # Rota: /api/consult-cpf/12345678900/
    path('consult-cpf/<str:cpf>/', views.consult_cpf, name='api_consult_cpf'),
]