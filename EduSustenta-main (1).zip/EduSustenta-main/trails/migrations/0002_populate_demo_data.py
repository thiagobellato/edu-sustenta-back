# edutrilhas/trails/migrations/0002_populate_demo_data.py

from django.db import migrations
from django.contrib.auth.hashers import make_password

def populate_data(apps, schema_editor):
    """
    Função principal que cria todos os dados de demonstração.
    """
    # 1. Obter os modelos da versão "histórica" do app
    User = apps.get_model('accounts', 'User')
    Trail = apps.get_model('trails', 'Trail')
    Level = apps.get_model('trails', 'Level')
    Activity = apps.get_model('trails', 'Activity')

    # 2. Criar um Professor de Demonstração
    # Usamos get_or_create para não duplicar, caso já exista
    professor_demo, created = User.objects.get_or_create(
        email='professor.demo@edutrilhas.com',
        defaults={
            'name': 'Prof. Demo',
            'role': 'PROFESSOR',
            'password': make_password('senhademo'),
            'is_staff': False,
            'is_superuser': False,
        }
    )

    # --- TRILHA 1: RECICLAGEM (Note a referência ao seu projeto ReciclaSmart) ---
    trilha_reciclagem = Trail.objects.create(
        name='Missão: ReciclaSmart',
        description='Aprenda a importância da reciclagem e como separar corretamente os resíduos.',
        theme='Reciclagem',
        created_by=professor_demo
    )

    # Nível 1 (Teoria)
    level1_rec = Level.objects.create(trail=trilha_reciclagem, title='Os 3 Rs', order=1)
    Activity.objects.create(
        level=level1_rec,
        type='TEORICA',
        content='''
        Os 3 Rs da sustentabilidade são: Reduzir, Reutilizar e Reciclar.
        1.  **Reduzir:** Gerar menos lixo. Evite comprar coisas desnecessárias e prefira produtos com menos embalagem.
        2.  **Reutilizar:** Dar um novo uso para objetos que iriam para o lixo. Um pote de vidro pode virar um copo ou um porta-lápis.
        3.  **Reciclar:** Transformar o material usado (como plástico, papel, vidro) em um produto novo.
        ''',
        points=10
    )

    # Nível 2 (Quiz)
    level2_rec = Level.objects.create(trail=trilha_reciclagem, title='Quiz: Coleta Seletiva', order=2)
    Activity.objects.create(
        level=level2_rec,
        type='QUIZ',
        content='''
        Qual é a cor da lixeira para descarte de PAPEL?
        (A) Vermelho
        (B) Verde
        (C) Azul
        (D) Amarelo
        
        (A resposta correta é C - Azul. O professor validará isso)
        ''',
        points=20
    )

    # Nível 3 (Prática)
    level3_rec = Level.objects.create(trail=trilha_reciclagem, title='Desafio: Lixo Zero', order=3)
    Activity.objects.create(
        level=level3_rec,
        type='PRATICA',
        content='''
        Desafio Prático: Tente passar 24 horas gerando o mínimo de lixo possível. 
        Anote tudo o que você jogou fora e pense em alternativas.
        Tire uma foto do seu "diário de lixo" e envie para o professor.
        ''',
        points=50
    )


    # --- TRILHA 2: ENERGIA LIMPA ---
    trilha_energia = Trail.objects.create(
        name='A Revolução da Energia',
        description='Descubra o que são energias renováveis e como podemos economizar eletricidade.',
        theme='Energia Limpa',
        created_by=professor_demo
    )

    # Nível 1 (Teoria)
    level1_ene = Level.objects.create(trail=trilha_energia, title='O que é Energia Limpa?', order=1)
    Activity.objects.create(
        level=level1_ene,
        type='TEORICA',
        content='''
        Energia limpa (ou renovável) vem de fontes que não se esgotam ou se regeneram rapidamente, como o sol (solar), o vento (eólica) e a água dos rios (hidrelétrica). 
        Elas são chamadas de "limpas" porque não liberam gases poluentes como a queima de petróleo ou carvão.
        ''',
        points=10
    )

    # Nível 2 (Quiz)
    level2_ene = Level.objects.create(trail=trilha_energia, title='Quiz: Aparelhos Vilões', order=2)
    Activity.objects.create(
        level=level2_ene,
        type='QUIZ',
        content='''
        Qual destes aparelhos geralmente consome MAIS energia em uma casa?
        (A) Lâmpada LED
        (B) Carregador de celular
        (C) Chuveiro Elétrico
        (D) Televisão
        
        (A resposta correta é C - Chuveiro Elétrico)
        ''',
        points=20
    )

    # Nível 3 (Prática)
    level3_ene = Level.objects.create(trail=trilha_energia, title='Missão: Detetive de Stand-by', order=3)
    Activity.objects.create(
        level=level3_ene,
        type='PRATICA',
        content='''
        Muitos aparelhos gastam energia mesmo "desligados" (em modo stand-by). 
        Sua missão é encontrar 5 aparelhos na sua casa que ficam com uma "luzinha" acesa. 
        Liste quais são e lembre-se de tirá-los da tomada quando não estiver usando!
        ''',
        points=50
    )

    # --- TRILHA 3: ÁGUA E CONSUMO CONSCIENTE ---
    trilha_agua = Trail.objects.create(
        name='Guardiões da Água',
        description='A água é um recurso finito. Vamos aprender a usá-la com sabedoria.',
        theme='Água',
        created_by=professor_demo
    )

    # Nível 1 (Teoria)
    level1_agua = Level.objects.create(trail=trilha_agua, title='A Pegada Hídrica', order=1)
    Activity.objects.create(
        level=level1_agua,
        type='TEORICA',
        content='''
        Você sabia que não gastamos água apenas bebendo ou tomando banho?
        A "Pegada Hídrica" é a quantidade total de água usada para produzir os alimentos que comemos e os produtos que compramos.
        Por exemplo, para produzir 1kg de carne bovina, são necessários mais de 15 mil litros de água!
        ''',
        points=10
    )

    # Nível 2 (Prática)
    level2_agua = Level.objects.create(trail=trilha_agua, title='Desafio do Banho Rápido', order=2)
    Activity.objects.create(
        level=level2_agua,
        type='PRATICA',
        content='''
        Cronometre seu banho hoje. Tente reduzir o tempo em 2 minutos nos próximos 3 dias. 
        Anote o tempo em um papel e relate se conseguiu cumprir o desafio. 
        Cada minuto a menos economiza muitos litros de água!
        ''',
        points=40
    )


def reverse_populate(apps, schema_editor):
    """
    Função que reverte a migração (apaga os dados criados).
    """
    User = apps.get_model('accounts', 'User')
    Trail = apps.get_model('trails', 'Trail')

    # Apaga as trilhas e (em cascata) seus níveis e atividades
    Trail.objects.filter(name__in=[
        'Missão: ReciclaSmart',
        'A Revolução da Energia',
        'Guardiões da Água'
    ]).delete()

    # Apaga o usuário de demonstração
    User.objects.filter(email='professor.demo@edutrilhas.com').delete()


class Migration(migrations.Migration):

    dependencies = [
        # A sua migração anterior (ex: '0001_initial') e a de 'accounts'
        ('trails', '0001_initial'), 
        ('accounts', '0001_initial'),
    ]

    operations = [
        # Executa a função populate_data
        migrations.RunPython(populate_data, reverse_populate),
    ]