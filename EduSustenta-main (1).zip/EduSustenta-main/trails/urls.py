from django.urls import path
from . import views

urlpatterns = [
    # Dashboard (Roteador)
    path('', views.homepage, name='homepage'),

    path('dashboard/', views.dashboard, name='dashboard'),

    # --- URLs de Professor ---
    path('dashboard/professor/', views.ProfessorDashboardView.as_view(), name='professor_dashboard'),
    path('trail/new/', views.TrailCreateView.as_view(), name='trail_create'),
    # (Adicionar URLs de Update e Delete aqui no futuro)
    
    # --- URLs de Aluno ---
    path('dashboard/aluno/', views.AlunoDashboardView.as_view(), name='aluno_dashboard'),
    path('progress/', views.StudentProgressView.as_view(), name='student_progress'),

    # --- URLs Comuns (Visualização) ---
    path('trail/<int:pk>/', views.TrailDetailView.as_view(), name='trail_detail'),
    path('activity/<int:pk>/', views.ActivityDetailView.as_view(), name='activity_detail'),
    
    # Ação de completar atividade
    path('activity/<int:pk>/complete/', views.mark_activity_complete, name='activity_complete'),
]