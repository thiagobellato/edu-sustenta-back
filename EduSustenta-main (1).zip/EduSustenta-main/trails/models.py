from django.db import models
from django.conf import settings # Importa o AUTH_USER_MODEL

class Trail(models.Model):
    name = models.CharField('Nome', max_length=200)
    description = models.TextField('Descrição')
    theme = models.CharField('Tema', max_length=100)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='created_trails',
        limit_choices_to={'role': 'PROFESSOR'} # Garante que apenas professores criem
    )

    def __str__(self):
        return self.name

class Level(models.Model):
    trail = models.ForeignKey(Trail, on_delete=models.CASCADE, related_name='levels')
    title = models.CharField('Título', max_length=200)
    order = models.PositiveIntegerField('Ordem', help_text="Ordem do nível na trilha (1, 2, 3...)")

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"{self.trail.name} - Nível {self.order}: {self.title}"

class Activity(models.Model):
    class ActivityType(models.TextChoices):
        TEORICA = 'TEORICA', 'Teórica'
        QUIZ = 'QUIZ', 'Quiz'
        PRATICA = 'PRATICA', 'Prática'

    level = models.ForeignKey(Level, on_delete=models.CASCADE, related_name='activities')
    type = models.CharField('Tipo', max_length=50, choices=ActivityType.choices)
    content = models.TextField('Conteúdo/Instruções')
    points = models.PositiveIntegerField('Pontuação', default=10)

    class Meta:
        ordering = ['level__order']

    def __str__(selfs):
        return f"{selfs.level.title} - {selfs.get_type_display()}"

class Progress(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='progress',
        limit_choices_to={'role': 'ALUNO'}
    )
    activity = models.ForeignKey(Activity, on_delete=models.CASCADE, related_name='progress')
    status = models.BooleanField('Concluída', default=False)
    # A pontuação é obtida da Atividade, aqui apenas marcamos se foi concluída.
    # O "score_obtained" poderia ser adicionado se um Quiz desse notas parciais.
    # Para o protótipo, 'status=True' é o suficiente.

    class Meta:
        # Garante que um aluno só possa completar uma atividade uma vez
        unique_together = ('student', 'activity')

    def __str__(self):
        return f"{self.student.email} - {self.activity.id} ({self.status})"