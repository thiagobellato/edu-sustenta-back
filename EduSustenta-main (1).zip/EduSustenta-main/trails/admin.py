
from django.contrib import admin
from .models import Trail, Level, Activity, Progress

# Para facilitar os testes, registre tudo no Admin
admin.site.register(Trail)
admin.site.register(Level)
admin.site.register(Activity)
admin.site.register(Progress)