from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy
from django.db.models import Sum, Count, Q

from .models import Trail, Level, Activity, Progress
from accounts.models import User # Importamos nosso usuário customizado

def homepage(request):
    """
    Renderiza a página inicial pública (landing page).
    Não tem @login_required.
    """
    return render(request, 'index.html')


# --- Mixins de Permissão ---

class ProfessorRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Garante que o usuário está logado E é um professor."""
    def test_func(self):
        return self.request.user.role == User.Role.PROFESSOR

class AlunoRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Garante que o usuário está logado E é um aluno."""
    def test_func(self):
        return self.request.user.role == User.Role.ALUNO

# --- View de Dashboard (Roteador) ---

@login_required
def dashboard(request):
    """
    Redireciona o usuário para o dashboard correto
    baseado no seu papel (role).
    """
    if request.user.role == User.Role.PROFESSOR:
        return redirect('professor_dashboard')
    elif request.user.role == User.Role.ALUNO:
        return redirect('aluno_dashboard')
    else:
        # Caso para admin ou outros
        return redirect('admin:index')

# --- Fluxo do Professor ---

class ProfessorDashboardView(ProfessorRequiredMixin, ListView):
    """Tela 2: Dashboard do professor (listar trilhas criadas)"""
    model = Trail
    template_name = 'professor_dashboard.html'
    context_object_name = 'trails'

    def get_queryset(self):
        # Retorna apenas as trilhas criadas pelo professor logado
        return Trail.objects.filter(created_by=self.request.user)

class TrailCreateView(ProfessorRequiredMixin, CreateView):
    """Professor: Criar Trilha"""
    model = Trail
    template_name = 'trail_form.html'
    fields = ['name', 'description', 'theme']
    success_url = reverse_lazy('professor_dashboard')

    def form_valid(self, form):
        # Associa o professor logado como o criador da trilha
        form.instance.created_by = self.request.user
        return super().form_valid(form)

# (Views de Update e Delete seriam similares, usando UpdateView e DeleteView)
# Para o protótipo, focaremos no fluxo principal.
# O CRUD de Níveis e Atividades pode ser feito via Admin ou
# com views mais complexas (ex: usando inlines) no futuro.

# --- Fluxo do Aluno e Visualização ---

class AlunoDashboardView(AlunoRequiredMixin, ListView):
    """Dashboard do Aluno (listar trilhas disponíveis)"""
    model = Trail
    template_name = 'aluno_dashboard.html'
    context_object_name = 'trails'
    # Por padrão, lista todas as trilhas.
    # No futuro: "trilhas em que o aluno está inscrito"

class TrailDetailView(LoginRequiredMixin, DetailView):
    """Tela 3: Tela de trilha (listar níveis e atividades)"""
    model = Trail
    template_name = 'trail_detail.html'
    context_object_name = 'trail'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Passamos os níveis ordenados para o template
        context['levels'] = self.object.levels.all().order_by('order')
        
        # Se for aluno, checamos o progresso
        if self.request.user.role == User.Role.ALUNO:
            # Pega IDs de todas as atividades concluídas pelo aluno NESTA trilha
            context['completed_activities'] = Progress.objects.filter(
                student=self.request.user,
                activity__level__trail=self.object,
                status=True
            ).values_list('activity_id', flat=True)
        return context


class ActivityDetailView(AlunoRequiredMixin, DetailView):
    """Tela 4: Tela de atividade (ver conteúdo)"""
    model = Activity
    template_name = 'activity_detail.html'
    context_object_name = 'activity'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Verifica se esta atividade específica já foi concluída
        context['is_completed'] = Progress.objects.filter(
            student=self.request.user,
            activity=self.object,
            status=True
        ).exists()
        return context

@login_required
def mark_activity_complete(request, pk):
    """Ação (POST) para marcar uma atividade como concluída"""
    if request.method == 'POST' and request.user.role == User.Role.ALUNO:
        activity = get_object_or_404(Activity, pk=pk)
        
        # Cria ou atualiza o progresso
        Progress.objects.update_or_create(
            student=request.user,
            activity=activity,
            defaults={'status': True} # Marca como concluída
        )
        
        # Redireciona de volta para a trilha
        return redirect('trail_detail', pk=activity.level.trail.pk)
    
    # Se não for POST ou não for aluno, apenas redireciona
    return redirect('dashboard')


class StudentProgressView(AlunoRequiredMixin, View):
    """Tela 5: Tela de progresso do aluno"""
    template_name = 'student_progress.html'

    def get(self, request, *args, **kwargs):
        student = request.user

        # 1. Total de atividades disponíveis (em todas as trilhas)
        total_activities = Activity.objects.count()
        
        # 2. Total de atividades concluídas pelo aluno
        completed_progress = Progress.objects.filter(student=student, status=True)
        completed_count = completed_progress.count()

        # 3. Pontuação total
        # Soma os pontos de todas as atividades que o aluno completou
        total_score = completed_progress.aggregate(
            total=Sum('activity__points')
        )['total'] or 0

        # 4. Percentual
        percentage = 0
        if total_activities > 0:
            percentage = (completed_count / total_activities) * 100

        context = {
            'total_score': total_score,
            'percentage_complete': round(percentage, 2),
            'completed_count': completed_count,
            'total_activities': total_activities,
        }
        return render(request, self.template_name, context)