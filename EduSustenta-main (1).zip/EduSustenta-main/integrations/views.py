# integrations/views.py

from django.http import JsonResponse
from django.conf import settings
from django.views.decorators.http import require_GET
import requests
import re
from datetime import datetime, date

# --- Helper para calcular idade (usado aqui e nos forms) ---
def calculate_age(birth_date_obj):
    if not birth_date_obj:
        return 0
    today = date.today()
    age = today.year - birth_date_obj.year - ((today.month, today.day) < (birth_date_obj.month, birth_date_obj.day))
    return age

@require_GET
def consult_cpf(request, cpf):
    cpf_cleaned = re.sub(r'\D', '', cpf)
    if not cpf_cleaned.isdigit() or len(cpf_cleaned) != 11:
        return JsonResponse({'success': False, 'error': 'Formato de CPF inválido.'}, status=400)

    headers = {
        'x-api-key': settings.CPF_HUB_API_KEY,
        'Accept': 'application/json'
    }
    url = f"https://api.cpfhub.io/cpf/{cpf_cleaned}"

    try:
        response = requests.get(url, headers=headers, timeout=5)
        response.raise_for_status()
        data = response.json()

        if data.get('success'):
            api_data = data.get('data', {})
            birth_date_str = api_data.get('birthDate') # "DD/MM/AAAA"
            birth_date_formatted = '' # "AAAA-MM-DD" (para o form)
            age = 0

            if birth_date_str:
                try:
                    date_obj = datetime.strptime(birth_date_str, '%d/%m/%Y')
                    birth_date_formatted = date_obj.strftime('%Y-%m-%d')
                    
                    # --- NOVA LÓGICA ---
                    # Calcula a idade para retornar ao front-end
                    age = calculate_age(date_obj.date())
                
                except ValueError:
                    pass

            return JsonResponse({
                'success': True,
                'name': api_data.get('name'),
                'birth_date': birth_date_formatted, # Para o <input type="date">
                'age': age # --- RETORNA A IDADE ---
            })
        else:
            return JsonResponse({'success': False, 'error': 'CPF não encontrado ou API recusou.'}, status=404)

    except requests.exceptions.RequestException as e:
        return JsonResponse({'success': False, 'error': f'Erro de conexão: {e}'}, status=500)