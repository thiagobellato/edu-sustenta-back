# edutrilhas/integrations/urls.py

from django.urls import path
from . import views

urlpatterns = [
    # Esta URL será acessada como /api/consult-cpf/12345678900/
    # (O /api/ vem do arquivo urls.py principal)
    path('consult-cpf/<str:cpf>/', views.consult_cpf, name='api_consult_cpf'),
]