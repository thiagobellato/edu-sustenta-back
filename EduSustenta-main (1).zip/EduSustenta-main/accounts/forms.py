# accounts/forms.py

from django import forms
from django.contrib.auth import forms as auth_forms
from .models import User
from datetime import date

# --- Helper de Idade ---
def calculate_age(birth_date_obj):
    if not birth_date_obj:
        return 0
    today = date.today()
    age = today.year - birth_date_obj.year - ((today.month, today.day) < (birth_date_obj.month, birth_date_obj.day))
    return age

# --- Formulários de Admin (Sem mudanças) ---
class CustomUserChangeForm(auth_forms.UserChangeForm):
    class Meta:
        model = User
        fields = ("email", "name", "role", "cpf", "birth_date", "is_active", "is_staff", "is_superuser", "groups", "user_permissions")
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if 'password' in self.fields: self.fields['password'].required = False
    def clean(self):
        cleaned_data = super().clean()
        role = cleaned_data.get('role')
        birth_date = cleaned_data.get('birth_date')
        if role == User.Role.PROFESSOR:
            age = calculate_age(birth_date)
            if age < 18: self.add_error('birth_date', 'Professores/Gestores devem ter 18 anos ou mais.')
        return cleaned_data

class CustomUserCreationForm(forms.ModelForm):
    password = forms.CharField(label='Senha', widget=forms.PasswordInput, strip=False)
    password2 = forms.CharField(label='Confirmação de senha', widget=forms.PasswordInput, strip=False, help_text='Informe a mesma senha anterior.')
    class Meta:
        model = User
        fields = ("email", "name", "role", "cpf", "birth_date", "groups", "user_permissions")
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name in ['name', 'role']: self.fields[field_name].required = True
        for field_name in ['groups', 'user_permissions']: self.fields[field_name].required = False
    def clean_password2(self):
        password, password2 = self.cleaned_data.get("password"), self.cleaned_data.get("password2")
        if password and password2 and password != password2: raise forms.ValidationError("As duas senhas não são iguais.")
        return password2
    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit: user.save(); self.save_m2m()
        return user
    def clean(self):
        cleaned_data = super().clean()
        role = cleaned_data.get('role')
        birth_date = cleaned_data.get('birth_date')
        if role == User.Role.PROFESSOR:
            age = calculate_age(birth_date)
            if age < 18: self.add_error('birth_date', 'Professores/Gestores devem ter 18 anos ou mais.')
        return cleaned_data


# Formulário de aluno
class AlunoRegistrationForm(forms.ModelForm):
    password = forms.CharField(label='Senha', widget=forms.PasswordInput, strip=False)
    password2 = forms.CharField(label='Confirme a senha', widget=forms.PasswordInput, strip=False)

    class Meta:
        model = User
        fields = ('name', 'email', 'cpf', 'birth_date')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # --- A CORREÇÃO ESTÁ AQUI ---
        # Eu tinha escrito 'for field_name in fields', o que causou o NameError.
        # Esta é a forma correta, definindo os campos manualmente:
        self.fields['name'].required = True
        self.fields['email'].required = True
        self.fields['cpf'].required = True
        self.fields['birth_date'].required = True
        # --- FIM DA CORREÇÃO ---
        
        self.fields['birth_date'].widget = forms.DateInput(attrs={'type': 'date'})
        self.fields['name'].widget.attrs['readonly'] = True
        self.fields['birth_date'].widget.attrs['readonly'] = True

    def clean_password2(self):
        password, password2 = self.cleaned_data.get("password"), self.cleaned_data.get("password2")
        if password and password2 and password != password2: raise forms.ValidationError("As duas senhas não são iguais.")
        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        user.role = User.Role.ALUNO # Define o papel
        if commit: user.save()
        return user

# 2. Formulário de Professor (Sem mudanças)
class ProfessorRegistrationForm(forms.ModelForm):
    password = forms.CharField(label='Senha', widget=forms.PasswordInput, strip=False)
    password2 = forms.CharField(label='Confirme a senha', widget=forms.PasswordInput, strip=False)
    nao_tenho_matricula = forms.BooleanField(
        label="Não tenho matrícula (sou de inst. privada)", 
        required=False
    )
    
    class Meta:
        model = User
        fields = ('name', 'email', 'cpf', 'birth_date', 
                  'matricula', 'nao_tenho_matricula', 'comprovante_vinculo')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['birth_date'].widget = forms.DateInput(attrs={'type': 'date'})
        self.fields['name'].widget.attrs['readonly'] = True
        self.fields['birth_date'].widget.attrs['readonly'] = True
        
        for field_name in ['name', 'email', 'cpf', 'birth_date', 'password', 'password2']:
            self.fields[field_name].required = True
        
        self.fields['matricula'].required = False
        self.fields['comprovante_vinculo'].required = False

    def clean_password2(self):
        password, password2 = self.cleaned_data.get("password"), self.cleaned_data.get("password2")
        if password and password2 and password != password2: raise forms.ValidationError("As duas senhas não são iguais.")
        return password2
    
    def clean(self):
        cleaned_data = super().clean()
        birth_date = cleaned_data.get('birth_date')
        matricula = cleaned_data.get('matricula')
        comprovante = cleaned_data.get('comprovante_vinculo')
        nao_tenho_matricula = cleaned_data.get('nao_tenho_matricula')

        age = calculate_age(birth_date)
        if age < 18:
            self.add_error('birth_date', 'Cadastro de professor/gestor é permitido apenas para maiores de 18 anos.')
        
        if nao_tenho_matricula and matricula:
            self.add_error('matricula', 'Não é possível preencher a matrícula e marcar "Não tenho matrícula" ao mesmo tempo.')
        
        if not nao_tenho_matricula and not matricula:
            self.add_error('matricula', 'A Matrícula é obrigatória (ou marque "Não tenho matrícula").')
        
        if nao_tenho_matricula and not comprovante:
            self.add_error('comprovante_vinculo', 'O Comprovante de Vínculo é obrigatório se você não possui matrícula.')
            
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        user.role = User.Role.PROFESSOR # Define o papel
        if commit: user.save()
        return user