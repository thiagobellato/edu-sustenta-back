# accounts/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import login
# Importamos os DOIS novos formulários
from .forms import AlunoRegistrationForm, ProfessorRegistrationForm
from .models import User

def register(request):
    """
    Lida com o cadastro de novos usuários.
    Agora mostra DOIS formulários (Aluno e Professor).
    """
    
    # Inicializa os formulários COM PREFIXOS
    aluno_form = AlunoRegistrationForm(prefix='aluno')
    professor_form = ProfessorRegistrationForm(prefix='prof')

    if request.method == 'POST':
        # 1. Verifica se o formulário ALUNO foi enviado
        if 'submit_aluno' in request.POST:
            # Adiciona o prefixo ao carregar dados POST
            aluno_form = AlunoRegistrationForm(request.POST, prefix='aluno')
            if aluno_form.is_valid():
                user = aluno_form.save()
                login(request, user)
                return redirect('dashboard')
            # Se for inválido, o 'professor_form' em branco (com prefixo) será enviado
            professor_form = ProfessorRegistrationForm(prefix='prof')

        # 2. Verifica se o formulário PROFESSOR foi enviado
        elif 'submit_professor' in request.POST:
            # Adiciona o prefixo ao carregar dados POST e FILES
            professor_form = ProfessorRegistrationForm(request.POST, request.FILES, prefix='prof')
            if professor_form.is_valid():
                user = professor_form.save()
                login(request, user)
                return redirect('dashboard')
            # Se for inválido, o 'aluno_form' em branco (com prefixo) será enviado
            aluno_form = AlunoRegistrationForm(prefix='aluno')

    # Se for um GET (ou um POST inválido), renderiza a página com ambos os forms
    context = {
        'aluno_form': aluno_form,
        'professor_form': professor_form
    }
    return render(request, 'registration/register.html', context)