# accounts/models.py

from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models

# --- GERENCIADOR DE USUÁRIO (Sem mudanças) ---
class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('O e-mail é obrigatório')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        extra_fields.setdefault('role', 'PROFESSOR')
        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')
        return self.create_user(email, password, **extra_fields)


# --- MODELO DE USUÁRIO (Atualizado) ---
class User(AbstractUser):
    class Role(models.TextChoices):
        PROFESSOR = 'PROFESSOR', 'Professor'
        ALUNO = 'ALUNO', 'Aluno'

    username = None
    email = models.EmailField('e-mail', unique=True)
    name = models.CharField('Nome Completo', max_length=255, blank=True)
    role = models.CharField('Papel', max_length=50, choices=Role.choices, blank=True)
    cpf = models.CharField('CPF', max_length=11, unique=True, null=True, blank=True)
    birth_date = models.DateField('Data de Nascimento', null=True, blank=True)

    # --- NOVOS CAMPOS PARA PROFESSOR ---
    matricula = models.CharField(
        'Matrícula (Serv. Público)', 
        max_length=100, 
        null=True, 
        blank=True
    )
    comprovante_vinculo = models.FileField(
        'Comprovante de Vínculo (Privado)',
        upload_to='comprovantes_vinculo/', # Salva em /media/comprovantes_vinculo/
        null=True,
        blank=True
    )
    # -----------------------------------

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['name']
    objects = CustomUserManager()

    def __str__(self):
        return self.email